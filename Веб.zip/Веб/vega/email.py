from flask import render_template
from flask_mail import Message
from vega import mail


def send_email(subject, recipients, text_body, html_body):
    msg = Message(subject, recipients=recipients)
    msg.body = text_body
    msg.html = html_body
    mail.send(msg)


def send_password_reset_email(user, token):
    send_email('[GPO1904] Reset Your Password',
               recipients=[user],
               html_body=render_template('rst_password.html', user=user, token=token),
               text_body=render_template('reset_password.txt', user=user, token=token)
               )
