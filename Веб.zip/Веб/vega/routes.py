from flask import render_template, request, redirect, url_for, flash, session
import json, datetime, tzlocal
from websocket import create_connection
from vega import app
from .forms import LoginForm, CreateUserForm, ResetPasswordEmail, ResetPassword, AddDeviceOTAAForm, AddDeviceABPForm, DevGraphForm, roles
from .email import send_password_reset_email
from hashlib import sha256
from .topsecret import root_password

URL_WS = "ws://localhost:8002/"

success_result_add_device_list = [
    "added",
    "updated",
    "nothingToUpdate",
    "updateViaMacBuffer"
]

def send_req(req: dict) -> dict:
    ws = create_connection(url=URL_WS)
    if req.get("cmd") != "auth_req":
        recovery_session = {"cmd": "token_auth_req", 'token': session.get('token')}
        ws.send(json.dumps(recovery_session))
        resp_json = json.loads(ws.recv())
        if resp_json.get('cmd') == "console":
            ws.recv()
        if resp_json.get("status"):
            session['token'] = resp_json.get('token')
    ws.send(json.dumps(req))  # Get command
    aaa = ws.recv()
    if aaa == "":
        return send_req(req)
    resp_json = json.loads(aaa)
    if resp_json.get('cmd') == "console":
        resp_json = json.loads(ws.recv())
        if resp_json == "" or resp_json.get("cmd") == "console":
            return send_req(req)
    ws.close()
    return resp_json


def add_device(set_data):
    query = {
        "cmd": "manage_devices_req",
        "devices_list": [set_data]
    }
    return send_req(query)


def getDataForIndexChart(devices, datefrom, dateto, limit):
    data_chart = dict()
    query_request = {
        "cmd": "get_data_req",
        "select": {}
    }
    if datefrom != 0:
        query_request["select"]['date_from'] = datefrom
    if dateto != 0:
        query_request["select"]['date_to'] = dateto
    if limit != 0:
        query_request["select"]['limit'] = limit

    data_list = dict()
    lables = []
    devalistresp = send_req({"cmd": "get_device_appdata_req"}).get("devices_list")

    for device in devices:
        query_request["devEui"] = device
        data_list[device] = send_req(query_request).get('data_list')

    for device in devices:
        data_chart[device] = {"device": [dev.get("devName") for dev in devalistresp if dev.get("devEui") == device][0], "climate": [], "pressure": [], "humidity": []}

        for data_item in data_list[device]:
            data_item['ts'] = datetime.datetime.fromtimestamp(data_item.get('ts') / 1000).strftime("%d-%m-%Y %H:%M")
            lables.append(data_item.get('ts'))

            raw_data = str(data_item.get('data'))
            if raw_data[-1] == '1':
                raw_data = raw_data[:-1]
            elif raw_data[-2] == '1':
                raw_data = raw_data[:-3]
            elif raw_data[-2] == '0':
                raw_data = raw_data[:-2]

            data_chart[device]["climate"].append(int(raw_data[0:2]))
            data_chart[device]["pressure"].append((int(raw_data[2:5])*0.75))
            data_chart[device]["humidity"].append(int(raw_data[5:7]))
    data_chart["lables"] = lables
    raw_data_list = []
    data_chart["devices"] = dict()
    for device in devices:
        data_chart["devices"][device] = data_chart[device]
        data_chart.pop(device)

    for device in data_chart["devices"]:
        for x in range(len(data_chart["devices"][device]["climate"])):
            element = {
                'Устройство': [dev.get("devName") for dev in devalistresp if dev.get("devEui") == device][0],
                'Температура': data_chart["devices"][device]["climate"][x],
                'Давление': data_chart["devices"][device]["pressure"][x],
                'Влажность': data_chart["devices"][device]["humidity"][x],
                'Дата': data_chart["lables"][x]
            }
            raw_data_list.append(element)
    data_chart["raw_data_list"] = raw_data_list
    data_chart["raw_data_list_keys"] = raw_data_list[0].keys() if raw_data_list else []
    return data_chart


def navbar_footer_data(context: dict) -> dict:
    # Get information from connected server
    infresp_dict = send_req({"cmd": "server_info_req"})
    if infresp_dict.get("err_string") == "unknown_auth":
        context["error"] = True
        return context
    if "manage_users" in session.get("command_list"):
        context['is_can_create_user'] = True
    if "manage_devices" in session.get("command_list"):
        context['is_can_add_device'] = True
    if "delete_users" in session.get("command_list"):
        context['is_can_delete_user'] = True
    if "delete_devices" in session.get("command_list"):
        context['is_can_delete_device'] = True
    if "get_data" in session.get("command_list"):
        context['is_can_get_data'] = True
    if "get_devices" in session.get("command_list"):
        context['is_can_view_devices'] = True
    if 'get_users' in session.get("command_list"):
        context['is_can_view_users'] = True
    time_serv_now = infresp_dict.get("time").get("utc") / 1000
    local_timezone = tzlocal.get_localzone()
    serv_time = datetime.datetime.fromtimestamp(time_serv_now, local_timezone)
    context['time'] = serv_time.strftime("%Y-%m-%d %H:%M:%S")
    context['city'] = infresp_dict.get("time").get("time_zone", 'None')
    return context


@app.route("/device_list/delete_device/<string:dev_eui>", methods=["GET"])
def delete_device(dev_eui):
    query = {
        "cmd": "delete_devices_req",
        "devices_list": [dev_eui]
    }
    resp = send_req(query)
    if resp.get("status") and resp.get("device_delete_status")[0].get('status') == 'deleted':
        flash("Device was deleted", "info")
    else:
        flash(f"Device was not deleted, because '{resp.get('err_string')}'", "error")
    return redirect(url_for('index'))


@app.route("/user_list/delete_user/<string:user>", methods=["GET"])
def delete_user(user):
    query = {
        "cmd": "delete_users_req",
        "user_list": [user]
    }
    resp = send_req(query)

    if resp.get("status") and resp.get("err_string") is None:
        flash("user was deleted", "info")
    else:
        flash(f"User was not deleted, because '{resp.get('err_string')}'", "error")
    return redirect(url_for('user_list'))


@app.route('/create_user/', methods=['post', 'get'])
def create_user():
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    form = CreateUserForm()
    if request.method == "POST":
        form.devEui_list.choices = form.devEui_list.data
    if form.validate_on_submit():
        command_list = list()
        for r in roles:
            if r['name'] == form.role.data:
                command_list = r['command_list']
        set_data = {
            "login": form.login.data,
            "password": form.password.data,
            "device_access": form.device_access.data,
            "consoleEnable": form.console_enable.data,
            "devEui_list": form.devEui_list.data,
            "command_list": command_list,
            "rx_settings": {
                "unsolicited": form.unsolicited.data,
                "direction": form.direction.data,
                "withMacCommands": form.with_MAC_Commands.data
            }
        }
        query = {
            "cmd": "manage_users_req",
            "user_list": [set_data]
        }
        resp = send_req(query)
        if resp.get("err_string") is None:
            return redirect(url_for('index'))
        else:
            flash(resp.get("err_string"), 'error')
        return render_template('create_user.html', form=form, context=context)
    query = {
        "cmd": "get_devices_req"
    }
    resp = send_req(query)
    devices_list = resp.get("devices_list")
    form.devEui_list.data = [dev.get("devName") for dev in devices_list]
    dev_Euis = [dev.get("devEui") for dev in devices_list]
    form.devEui_list.choices = dev_Euis
    return render_template('create_user.html', form=form, context=context)


@app.route('/add_device/OTAA', methods=['post', 'get'])
def add_device_otaa():
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    form = AddDeviceOTAAForm()
    if form.validate_on_submit():
        dev_eui = form.dev_eui.data
        dev_name = form.dev_name.data
        app_eui = form.app_eui.data
        app_key = form.app_key.data
        class_user = form.class_user.data
        set_data = {
            "devEui": dev_eui,
        }
        if dev_name is not None:
            set_data["devName"] = dev_name
        otaa = {
            "appKey": app_key,
        }
        if app_eui != "":
                otaa["appEui"] = app_eui
        set_data["OTAA"] = otaa

        if class_user is not None:
            set_data["class"] = class_user

        resp = add_device(set_data)

        if resp.get("err_string") is None and resp.get('device_add_status')[0].get(
                "status") in success_result_add_device_list:
            return redirect(url_for('index'))
        else:
            flash(resp.get('device_add_status')[0].get("status"), 'error')
        return render_template('Устройства/add_device_OTAA.html', form=form, context=context)
    return render_template('Устройства/add_device_OTAA.html', form=form, context=context)


@app.route('/add_device/ABP', methods=['post', 'get'])
def add_device_abp():
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    form = AddDeviceABPForm()
    if form.validate_on_submit():
        dev_eui = form.dev_eui.data
        dev_name = form.dev_name.data
        dev_address = form.dev_address.data
        apps_key = form.apps_key.data
        nwks_key = form.nwks_key.data
        class_user = form.class_user.data
        set_data = {
            "devEui": dev_eui,
            "ABP": {
                "devAddress": dev_address,
                "appsKey": apps_key,
                "mwksKey": nwks_key
            }
        }
        if dev_name is not None:
            set_data["devName"] = dev_name
        if class_user is not None:
            set_data["class"] = class_user
        resp = add_device(set_data)

        if resp.get("err_string") is None and resp.get('device_add_status')[0].get(
                "status") in success_result_add_device_list:
            return redirect(url_for('index'))
        else:
            flash(resp.get('device_add_status')[0].get("status"), 'error')
        return render_template('Устройства/add_device_ABP.html', form=form, context=context)
    return render_template('Устройства/add_device_ABP.html', form=form, context=context)


@app.route('/')
def index():
    if session.get('role') == 'Гость':
        return redirect('dev_graph')
    else:
        return redirect('device_list')


@app.route('/device_list/')
def device_list():
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    devalistresp = send_req({"cmd": "get_device_appdata_req"})
    context["devices_list"] = devalistresp.get("devices_list")
    for index in range(len(context["devices_list"])):
        data = send_req({"cmd": "get_data_req", "devEui": context["devices_list"][index]["devEui"], "select": { "limit": 1 }})
        raw_data = str(data.get("data_list")[0]["data"]) if len(data.get("data_list")) != 0 else ""
        if len(raw_data) > 0:
            if raw_data[-1] == '1':
                raw_data = raw_data[:-1]
            elif raw_data[-2] == '1':
                raw_data = raw_data[:-3]
            elif raw_data[-2] == '0':
                raw_data = raw_data[:-2]
        context["devices_list"][index]["charge"] = "null" if len(data.get("data_list")) == 0 or len(raw_data) <= 8 else str(raw_data[-3:-2])+"."+str(raw_data[-2:])
    return render_template('Устройства/DevicesRoute.html', context=context)


@app.route('/user_list/')
def user_list():
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    reguserresponse = send_req({"cmd": "get_users_req"})
    context["user_list"] = reguserresponse.get("user_list")
    return render_template('UsersRoute.html', context=context)


@app.route('/dev_graph/', methods=['post', 'get'])
def dev_graph():
    form = DevGraphForm()
    context = navbar_footer_data(dict())
    if "error" in context:
        return redirect(url_for("login"))
    context["role"] = session["role"]

    devalistresp = send_req({"cmd": "get_device_appdata_req"})
    context["devices_list"] = devalistresp.get("devices_list")
    form.devEui_list.choices = [dev.get("devName") for dev in context["devices_list"]]
    datachart = getDataForIndexChart(["AC1F09FFFE015302"], 0,0, 10)

    if form.is_submitted():
        datefrom = 0 if form.dateFrom.data is None else int(form.dateFrom.data.timestamp())*1000
        dateto = 0 if form.dateTo.data is None else int(form.dateTo.data.timestamp())*1000
        ChLimit = 0 if form.ChLimit.data is None else int(form.ChLimit.data)
        devices = [device.get("devEui") for device in context["devices_list"] if device.get("devName") in form.devEui_list.data]
        if context["role"] == "Гость":
            datefrom = 0
            dateto = 0
            ChLimit = 10
        datachart = getDataForIndexChart(devices, datefrom, dateto, ChLimit)
    return render_template("devgraphroute.html", context=context, datachart=datachart, form=form)


@app.route('/logout/')
def logout():
    if 'token' in session:
        close_auth = send_req({"cmd": "close_auth_req",  # Don't change!
                   "token": session.get("token")
                   })
        if close_auth.get("err_string") is None:
            flash("You have been logged out")
            session.pop('token', None)
            return redirect(url_for('login'))
    return redirect(url_for('login'))


@app.route('/login/', methods=['post', 'get'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        autreq = {
            "cmd": "auth_req",
            "login": form.login.data,
            "password": form.password.data
        }
        autresp = send_req(autreq)
        if autresp.get("err_string") is None:
            session["command_list"] = autresp.get("command_list")
            if form.login.data == 'root':
                session['role'] = 'root'
            elif 'create_user' in autresp.get("command_list"):
                session['role'] = 'Администратор'
            elif 'get_devices' in autresp.get("command_list"):
                session['role'] = 'Оператор системы'
            else:
                session['role'] = 'Гость'
            session['token'] = autresp.get("token")
            return redirect(url_for('index'))
        else:
            flash("Invalid login/password", 'error')
    return render_template('login.html', form=form)


@app.route('/reset_password_email', methods=['GET', 'POST'])
def reset_password_email():
    if "user" in session:
        session.pop("user", None)
    form = ResetPasswordEmail()
    if form.validate_on_submit():
        dateform = {"login": form.login.data, "email": form.eml.data}

        #Вход рута
        autresp = send_req({"cmd": "auth_req", "login": "root", "password": root_password})
        session["token"] = autresp.get("token")

        #Поиск юзера в списке юзеров
        allusers = send_req({"cmd": "get_users_req"}).get("user_list")
        for onethe in allusers:
            if onethe.get('login') == dateform['login']:
                session["user"] = onethe
                break

        if "user" in session:
            #генерация токена алгоритмом sha256 на основе логина
            token = sha256(session["user"].get("login").encode('utf-8')).hexdigest()
            # Выход рута
            out = send_req({"cmd": "close_auth_req", "token": session.get("token")})
            if out.get("err_string") is None:
                session.pop('token', None)

            send_password_reset_email(dateform.get("email"), token)
            flash('Check your email for the instructions to reset your password')
            return redirect(url_for('login'))
        else:
            flash("The user does not exist")
            return redirect(url_for('login'))
    return render_template('Пароль/reset_password_email.html', form=form)


@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    form = ResetPassword()
    if token != sha256(session["user"].get("login").encode('utf-8')).hexdigest():
        flash("token is not true")
        return redirect(url_for('login'))

    user = session.get('user')

    # Вход рута
    autresp = send_req({"cmd": "auth_req", "login": "root", "password": root_password})
    session["token"] = autresp.get("token")

    if form.validate_on_submit():
        session.pop('user', None)

        delus = send_req({"cmd": "delete_users_req", "user_list": [user.get("login")]})

        if delus.get("status") and delus.get("err_string") is None:
            resp = send_req({
                "cmd": "manage_users_req",
                "user_list": [
                    {
                        "login": user.get("login"),
                        "password": form.password.data,
                        "device_access": user.get("device_access"),
                        "devEui_list": user.get("devEui_list"),
                        "command_list": user.get("command_list"),
                        "rx_settings": user.get("rx_settings")
                    }
                ]
            })

            # Выход рута
            out = send_req({"cmd": "close_auth_req", "token": session.get("token")})
            if out.get("err_string") is None:
                session.pop('token', None)

            if resp.get("status") and resp.get("err_string") is None:
                flash('Your password has been reset.')
                return redirect(url_for('login'))
            else:
                flash("Error, try again")
                return redirect(url_for('login'))
        else:
            # Выход рута
            out = send_req({"cmd": "close_auth_req", "token": session.get("token")})
            if out.get("err_string") is None:
                session.pop('token', None)
                
            flash("Error, try again")
            return redirect(url_for('login'))
    return render_template('Пароль/reset_password.html', form=form)