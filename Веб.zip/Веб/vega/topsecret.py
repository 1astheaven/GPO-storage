mail_password = 'afsc ofhu qhjl wldp'
secret_key = 'hard to guess'
root_password = "123456"