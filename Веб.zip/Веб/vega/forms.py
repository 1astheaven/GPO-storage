import wtforms
from flask_wtf import FlaskForm
from wtforms.validators import Length, InputRequired, NumberRange, ValidationError, DataRequired, Email, EqualTo

all_command_list = [
    "get_users",
    "manage_users",
    "delete_users",
    "get_device_appdata",
    "get_data",
    "send_data",
    "manage_device_appdata",
    "delete_device_appdata",
    "get_gateways",
    "manage_gateways",
    "delete_gateways",
    "get_devices",
    "manage_devices",
    "delete_devices",
    "get_coverage_map",
    "get_device_downlink_queue",
    "manage_device_downlink_queue",
    "server_info",
    "send_email",
    "tx"
]

roles = [
    {
        'name': 'Администратор',
        'command_list': all_command_list,
        },
    {
        'name': 'Оператор системы',
        'command_list': [
            'get_devices',
            'get_device_appdata',
            'get_data',
            'server_info'
            ]
        },
    {
        'name': 'Гость',
        'command_list':[
            'get_device_appdata',
            'get_data',
            'server_info'
            ]
        }
]

class LoginForm(FlaskForm):
    login = wtforms.StringField("Логин: ", validators=[InputRequired()])
    password = wtforms.PasswordField("Пароль: ", validators=[InputRequired(), Length(min=1, max=100)])
    submit = wtforms.SubmitField("Войти")


class ResetPasswordEmail(FlaskForm):
    login = wtforms.StringField("Логин: ", validators=[InputRequired()])
    eml = wtforms.StringField("Электронная почта: ", validators=[DataRequired(), Email()])
    send = wtforms.SubmitField("Отправить ссылку")


class ResetPassword(FlaskForm):
    password = wtforms.PasswordField("Новый пароль: ", validators=[DataRequired(),
                                                                   Length(min=8)])
    passwordtwo = wtforms.PasswordField("Повторите пароль: ", validators=[DataRequired(message='*Required'),
                                                                          EqualTo('password',
                                                                                  message='Пароли должны совпадать!')])
    reset = wtforms.SubmitField("Сбросить")


class CreateUserForm(FlaskForm):
    login = wtforms.StringField("Логин: ", validators=[InputRequired()])
    password = wtforms.PasswordField("Пароль: ", validators=[DataRequired(),
                                                             Length(min=8)])
    device_access = wtforms.SelectField("Доступ к устройству: ", choices=["FULL", "SELECTED"], default="SELECTED")
    console_enable = wtforms.BooleanField("Работа с консолью:")
    devEui_list = wtforms.SelectMultipleField("Список устройств:")
    role = wtforms.SelectField("Список ролей:", choices=[role['name'] for role in roles])
    unsolicited = wtforms.BooleanField("Unsolicited:")
    direction = wtforms.SelectField("Направление:", choices=["UPLINK", "DOWNLINK", "ALL"])
    with_MAC_Commands = wtforms.BooleanField("С MAC командами:")
    submit = wtforms.SubmitField("Внести")


def is_string_is_hex(form, field):
    for ch in field.data:
        if ((ch < '0' or ch > '9') and
                (ch < 'A' or ch > 'F')):
            raise ValidationError('Field must be in HEX')


class AddDeviceForm(FlaskForm):
    dev_eui = wtforms.StringField("EUI устройства*: ",
                                  validators=[InputRequired(), is_string_is_hex,
                                              Length(16, 16, message="Must be 16 length")])
    dev_name = wtforms.StringField("Имя устройства: ")
    class_user = wtforms.SelectField("Класс пользователя", choices=['CLASS_A', 'CLASS_C'])
    submit = wtforms.SubmitField("Добавить")


class AddDeviceABPForm(AddDeviceForm):
    dev_address = wtforms.IntegerField(
        "Адрес устройства: ",
        validators=[NumberRange(min=0x00000001, max=0xFFFFFFFF, message="0x00000001 and 0xFFFFFFFF desired")])
    apps_key = wtforms.StringField("Application session key: ",
                                   validators=[Length(32, 32, message="Must be 32 length"), is_string_is_hex],
                                   default="")
    nwks_key = wtforms.StringField("Network session key: ",
                                   validators=[Length(32, 32, message="Must be 32 length"), is_string_is_hex],
                                   default="")


class AddDeviceOTAAForm(AddDeviceForm):
    app_eui = wtforms.StringField("Application EUI: ",
                                  validators=[Length(16, 16, message="Must be 16 length"), is_string_is_hex],
                                  default="")
    app_key = wtforms.StringField("Application key: ",
                                  validators=[Length(32, 32, message="Must be 32 length"), is_string_is_hex],
                                  default="")


class DevGraphForm(FlaskForm):
    devEui_list = wtforms.SelectMultipleField("Выберите устройство")
    dateFrom = wtforms.DateTimeLocalField("С", format='%Y-%m-%dT%H:%M')
    dateTo = wtforms.DateTimeLocalField("До", format='%Y-%m-%dT%H:%M')
    ChLimit = wtforms.IntegerField("Количество данных", validators=[NumberRange(min=1)])
    submit = wtforms.SubmitField("Показать")
