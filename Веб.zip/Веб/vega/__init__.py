from flask import Flask
from flask_mail import Mail
from datetime import timedelta
import os
from .topsecret import mail_password, secret_key

app = Flask(__name__, static_folder="static")
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SECRET_KEY'] = secret_key
app.config['MAIL_SERVER'] = 'smtp.googlemail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'zaharovd840@gmail.com'
app.config['MAIL_DEFAULT_SENDER'] = 'zaharovd840@gmail.com'
app.config['MAIL_PASSWORD'] = mail_password
mail = Mail(app)
