from vega import app
from vega import routes

context = ('newcert.crt', 'newkey.key')
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=443, debug=True, ssl_context=context)