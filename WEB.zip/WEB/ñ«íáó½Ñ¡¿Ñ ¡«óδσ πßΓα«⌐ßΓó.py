##Python v.3.10.  IDLE v.3.10
## pip3 install websocket-client
from websocket import create_connection
import json
import time

#### Data section

## Autorization on VEGA server
autreq = {"cmd":"auth_req", # Don't change!
"login": "root", # Login name
"password": "123456" # password
}
## Get information from connected server
srvinfo = {"cmd":"server_info_req"} # Don't change!

## Add new device(s)
adddev = {"cmd":"manage_devices_req",  # Don't change!
"devices_list":
 [
  {
      "devEui":"AC1F09FFFE0152FF",
      "devName":"test_add",
      "class":"CLASS_A",
      "OTAA":
      {
          "appEui": "AC1F09FFF8680811",
          "appKey": "AC1F09FFFE0152FFAC1F09FFF8680811"
      }
   }
  ]
}
### ============
### Code section

##Connection to VEGA server
ws = create_connection("ws://192.168.17.106:8002/") # Start connection. IP Address:Port VEGA server
ws.send(json.dumps(autreq))                    # Get Autorization command
autresp = ws.recv()                         #Status (responce) of execute command

print(autresp)
print("==========================")

## Get server info
ws.send(json.dumps(srvinfo))                    # Get command
srvinfresp = ws.recv()  
#ws.send(json.dumps(srvinfo))                    # Get command
#srvinfresp = ws.recv()                         #Status (responce) of execute command

print(srvinfresp)
print("==========================")

## Add new device(s)
ws.send(json.dumps(adddev))                    # Get command
adddevresp = ws.recv()
#ws.send(json.dumps(adddev))                    # Get command
#adddevresp = ws.recv()
print(adddevresp)
print("==========================")

##Close connection to VEGA server
ws.close()
