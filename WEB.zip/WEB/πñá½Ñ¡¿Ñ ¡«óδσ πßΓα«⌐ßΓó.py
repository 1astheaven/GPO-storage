##Python v.3.10.  IDLE v.3.10
## pip3 install websocket-client
from websocket import create_connection
import json
import time

#### Data section

## Autorization on VEGA server
autreq = {"cmd":"auth_req", # Don't change!
"login": "root", # Login name
"password": "123456" # password
}

## Delete added device(s)
deldev = {"cmd":"delete_devices_req",  # Don't change!
"devices_list":
 [
     "00137A1000002EF5"
 ]
         } 

### ============
### Code section

##Connection to VEGA server
ws = create_connection("ws://192.168.17.106:8002/") # Start connection. IP Address:Port VEGA server
ws.send(json.dumps(autreq))                    # Get Autorization command
autresp = ws.recv()                         #Status (responce) of execute command

print(autresp)
print("==========================")

## Delete device(s)
ws.send(json.dumps(deldev))                    # Get command
deldevresp = ws.recv()
#ws.send(json.dumps(deldev))                    # Get command
#deldevresp = ws.recv()
print(deldevresp)
print("==========================")

##Close connection to VEGA server
ws.close()
