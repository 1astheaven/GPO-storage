from flask import render_template, request, redirect, url_for, flash, session
import json
from websocket import create_connection
from vega import app, db
import time
from datetime import datetime
import tzlocal
from flask_login import login_required, login_user, current_user, logout_user

# from models import User
ws = None


def send_req(req: dict) -> dict:
    ws.send(json.dumps(req))  # Get command
    resp = ws.recv()
    resp_json = json.loads(resp)
    if resp_json.get('cmd') == "console":
        ws.recv()
        return send_req(req)
    print("==========================")
    print(f"|command - {req.get('cmd')}|")
    print(resp_json)
    print("==========================")
    return resp_json


@app.route('/login/', methods=['post', 'get'])
def login():
    # if current_user.is_authenticated:
    #     return redirect(url_for('index'))
    message = ''
    if request.method == 'POST':
        login = request.form.get('login')  # запрос к данным формы
        password = request.form.get('password')
        # user = db.session.query(User).filter(User.username == login).first()
        # if user and user.check_password(password):
        #     login_user(user, remember=True)

        # Autorization on VEGA server
        autreq = {"cmd": "auth_req",  # Don't change!
                  "login": str(login),  # Login name
                  "password": str(password)  # password
                  }
        print(json.dumps(autreq))
        # Connection to VEGA server
        # Start connection. IP Address:Port VEGA server
        global ws
        ws = create_connection("ws://localhost:8002/")

        autresp = send_req(autreq)
        if autresp.get("err_string") is None:
            session['token'] = autresp.get("token")
            return redirect(url_for('index'))
        else:
            flash("Invalid login/password", 'error')
    return render_template('login.html')

@app.route('/logout/')
def logout():
    if 'token' in session:
        global ws
        log_out = {"cmd": "close_auth_req",  # Don't change!
                   "token": session.get("token")
                   }
        ws.send(json.dumps(log_out))  # Get Autorization command
        out = ws.recv()  # Status (responce) of execute command
        if json.loads(out).get("err_string") is None:
            flash("You have been logged out.")
            session.pop('token', None)
            return redirect(url_for('login'))


@app.route('/')
def index():
    context = dict()
#     context['time'] = time.ctime()
#     context['city'] = 'izhevsk'
#
#     js_devs = """
# {
#     "cmd": "get_device_appdata_resp",
#     "status": true,
#     "devices_list": [
#         {
#             "devEui": "3933363845366606",
#             "appEui": "0000000000000001",
#             "devName": "Окно левое в комнате 1",
#             "adress1": "Novosibirsk",
#             "devType": "SI-11.VA",
#             "name": "test"
#         },
#         {
#             "devEui": "3933363845366607",
#             "appEui": "0000000000000001",
#             "devName": "Окно левое в комнате 2",
#             "adress1": "Novosibirsk",
#             "devType": "SI-11.VA",
#             "name": "test2"
#         }
#     ]
# }
#     """
#     context["devices_list"] = json.loads(js_devs)["devices_list"]
#
#     js_users = """
#     {
# "cmd": "get_users_resp",
# "status": true,
# "user_list":
# [
# {
# "login": "user1",
# "device_access": "SELECTED",
# "consoleEnable": true,
# "devEui_list":
# [
# "0000000000000001"
# ],
# "command_list":
# [
# "get_userlist",
# "update_userlist",
# "delete_userlist"
# ]
# }
# ]
# }
# """
#     context["user_list"] = json.loads(js_users)["user_list"]

    if 'token' not in session:
        return redirect('login')
    # Get information from connected server
    srvinfo = {"cmd": "server_info_req"}  # Don't change!

    # Get device list w/attributes
    devalist = {"cmd": "get_device_appdata_req"}  # Don't change!

    # Get data from devices
    datadev = {"cmd": "get_data_req",
               "devEui": "AC1F09FFFE015302"
               }  # Don't change!

    # Get reg users
    reguser = {"cmd": "get_users_req"}  # Don't change!

    # ============
    # Get server info
    global ws

    if ws is not None:
        infresp_dict = send_req(srvinfo)
        time_serv_now = infresp_dict.get("time").get("utc") / 1000
        local_timezone = tzlocal.get_localzone()
        serv_time = datetime.fromtimestamp(time_serv_now, local_timezone)
        context['time'] = serv_time.strftime("%Y-%m-%d %H:%M:%S")
        context['city'] = infresp_dict.get("time").get("time_zone", 'None')
        # Get dev list w/attributes
        devalistresp = send_req(devalist)
        context["devices_list"] = devalistresp.get("devices_list")

        # Get registered users
        reguserresponse = send_req(reguser)
        context["user_list"] = reguserresponse.get("user_list")

        # print(reguserresponse)
        # print("==========================")

        # while (True):
        #     # Get save data drom devices
        #     ws.send(json.dumps(datadev))  # Get command
        #     datadevresp = ws.recv()
        #     data_dict = json.loads(datadevresp)
        #     keys = data_dict.keys()
        #     keys1 = str(keys)
        #     if keys1 == "dict_keys(['appEui', 'cmd', 'data_list', 'devEui', 'direction', 'status', 'totalNum'])":
        #         data = [{"devEui": data_dict["devEui"]}, {"data": data_dict["data_list"][0]["data"]},
        #                 {"type": data_dict["data_list"][0]["type"]}]
        #         print(data)
        #         realtime = data_dict["data_list"][0]["ts"] / 1000
        #         packet_time = datetime.fromtimestamp(realtime, local_timezone)
        #         print(packet_time.strftime("%Y-%m-%d %H:%M:%S"))
        #     else:
        #         print(datadevresp)
        #     print("==========================")
        #     time.sleep(5)
        return render_template('index.html', context=context)